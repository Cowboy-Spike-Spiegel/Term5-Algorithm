package me.ericdeng.algcollection.dc;

import lombok.extern.slf4j.Slf4j;
import me.ericdeng.algcollection.checker.FFTChecker;
import me.ericdeng.algcollection.common.Complex;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static me.ericdeng.algcollection.dc.FFT.fft;
import static me.ericdeng.algcollection.dc.FFT.ifft;
import static org.junit.Assert.assertArrayEquals;

@Slf4j
class FFTTest {

    private static Complex[] x0;

    private static Complex[] x1;

    @BeforeEach
    void setUp() {
        int n = 4;
        x0 = new Complex[n];
        x1 = new Complex[n];

        for (int i = 0; i < x0.length; i++) {
            x0[i] = Complex.get(-2 * Math.random() + 1, 0);
        }
        for (int i = 0; i < n; i++) {
            x1[i] = Complex.get(-2 * Math.random() + 1, 0);
        }
    }

    @Test
    void fftAndIfftIsInverse() {
        log.info("x: {}", Arrays.toString(x0));
        Complex[] ifft0 = ifft(fft(x0));
        log.info("ifft(fft(x)): {}", Arrays.toString(ifft0));
        log.info("y: {}", Arrays.toString(x1));
        Complex[] ifft1 = ifft(fft(x1));
        log.info("ifft(fft(y)): {}", Arrays.toString(ifft1));
        assertArrayEquals(x0, ifft0);
        assertArrayEquals(x1, ifft1);
    }

    @Test
    void fftEqualsNaive() {
        Complex[] convolution = FFT.convolution(x0, x1);
        log.info("fft: x * y: {}", Arrays.toString(convolution));
        Complex[] naive = FFTChecker.naive(x0, x1);
        log.info("naive: x * y: {}", Arrays.toString(naive));
        assertArrayEquals(convolution, naive);
    }

}