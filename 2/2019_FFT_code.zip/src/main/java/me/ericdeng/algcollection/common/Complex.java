package me.ericdeng.algcollection.common;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

import static java.lang.Math.abs;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class Complex {

    public static final Complex ZERO = new Complex(0, 0);

    public static final Complex I = new Complex(0, 1);

    public static final Complex ONE = new Complex(1, 0);

    private static final double delta = 1e-8;

    @Getter
    private final double real;

    @Getter
    private final double imagine;

    public static Complex get(double real, double imagine) {
        return new Complex(real, imagine);
    }

    public Complex conjugate() {
        return get(real, -imagine);
    }

    public Complex scale(double scale) {
        return get(real * scale, imagine * scale);
    }

    public Complex add(Complex complex) {
        return get(real + complex.real, imagine + complex.imagine);
    }

    public Complex multiply(Complex complex) {
        return get(real * complex.real - imagine * complex.imagine,
                   real * complex.imagine + imagine * complex.real);
    }

    public Complex subtract(Complex complex) {
        return get(real - complex.real, imagine - complex.imagine);
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) { return true; }
        if (obj instanceof Complex) {
            return abs(real - ((Complex) obj).real) < delta && abs(imagine - ((Complex) obj).imagine) < delta;
        }
        return false;
    }

    @Override
    public int hashCode() {
        return (int) cantorPairing(real, imagine);
    }

    @Override
    public String toString() {
        return String.format("(%f, %f)", real, imagine);
    }

    private static double cantorPairing(double real, double virtual) {
        return (real + virtual) * (real + virtual + 1) / 2 + virtual;
    }

}
